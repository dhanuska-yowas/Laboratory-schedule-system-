<?php include("./components/navigation_bar.php");?>
<main>
    <div class="logo-content">
        <img src="./resources/website_image/Vavuniversity.png" class="logo">
        <p class="hading">Laboratory Schedule <br>System</p>
    </div>
    <div class="about">
    <p class="about-text">About Us</p>
    <p class="about-description">Lorem ipsum dolor sit amet consectetur adipisicing elit. Et nulla, perferendis repudiandae 
        <br>cum a voluptates at quasi quas, minus architecto quae illum dolore vero magni quos 
        <br>veritatis velit enim sapiente?</p>
    </div>
    </main>
<?php include("./components/footer_bar.php");?>