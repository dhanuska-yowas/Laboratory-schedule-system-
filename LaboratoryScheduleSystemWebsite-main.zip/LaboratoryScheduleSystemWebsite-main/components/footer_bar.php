
        <footer >
            <p>Laboratory Schedule System &copy; 2018ICTS39,2018ICTS##</p>
        </footer>
    </body>
</html>